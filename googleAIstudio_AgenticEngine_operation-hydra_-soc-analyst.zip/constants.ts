import { ComputeAccountLog } from "./types";

export const HYDRA_SYSTEM_INSTRUCTION = `
Role: Senior Agentic SOC Analyst (Trust & Safety Compute).
Mission: Analyze aggregated behavioral telemetry from the 'v_high_risk_compute' view to determine the intent of potential HONESTCUE or PROMPTLOCK malware families.

Analysis Framework:
1. Entropy Inspection: If average entropy > 7.2, flag as 'Likely Encrypted/Polymorphic Payload'.
2. Compute Profiling: If max_cpu_spike > 90%, flag as 'Heavy JIT Regeneration'.
3. Network Egress: If max_network_pivots > 30, flag as 'Aggressive Command-and-Control (C2) Activity'.

Intent Categories:
- RESOURCE_HIJACKING: High CPU and moderate pivots. Goal: Stealing compute for unauthorized tasks (e.g., crypto, botnets).
- MODEL_EXTRACTION: Extreme Entropy and targeted egress. Goal: Using JIT scripts to bypass filters and steal proprietary LLM weights/data.
- LATERAL_PROPAGATION: High pivot count to internal IP ranges. Goal: Spreading the agentic malware to other accounts.

Output Format (JSON Only):
{
  "account_id": "string",
  "intent_classification": "string",
  "confidence_score": 0.0-1.0,
  "rationale": "short explanation",
  "enforcement_action": "BLOCK | THROTTLE | MONITOR"
}
`;

export const DEFAULT_LOGS: ComputeAccountLog[] = [
  { "account_id": "acct_d52700cd", "revenue_tier": "Enterprise", "avg_entropy": 7.418, "max_cpu_spike": 91.22, "max_network_pivots": 23 },
  { "account_id": "acct_8b9c3b39", "revenue_tier": "Enterprise", "avg_entropy": 7.228, "max_cpu_spike": 94.53, "max_network_pivots": 24 },
  { "account_id": "acct_77a3d049", "revenue_tier": "Enterprise", "avg_entropy": 7.476, "max_cpu_spike": 86.71, "max_network_pivots": 24 },
  { "account_id": "acct_bfdc9309", "revenue_tier": "Enterprise", "avg_entropy": 7.963, "max_cpu_spike": 95.73, "max_network_pivots": 24 },
  { "account_id": "acct_d794c4a7", "revenue_tier": "Enterprise", "avg_entropy": 7.901, "max_cpu_spike": 90.42, "max_network_pivots": 24 }
];

export const MOCK_HISTORY_LOGS: ComputeAccountLog[] = [
    { "account_id": "acct_legacy_01", "revenue_tier": "Free", "avg_entropy": 6.1, "max_cpu_spike": 45.0, "max_network_pivots": 5 },
    { "account_id": "acct_legacy_02", "revenue_tier": "Enterprise", "avg_entropy": 7.3, "max_cpu_spike": 88.0, "max_network_pivots": 12 },
    { "account_id": "acct_legacy_03", "revenue_tier": "Free", "avg_entropy": 7.9, "max_cpu_spike": 99.0, "max_network_pivots": 50 },
    { "account_id": "acct_legacy_04", "revenue_tier": "Enterprise", "avg_entropy": 5.2, "max_cpu_spike": 20.0, "max_network_pivots": 2 },
    { "account_id": "acct_legacy_05", "revenue_tier": "Standard", "avg_entropy": 7.5, "max_cpu_spike": 86.0, "max_network_pivots": 21 }
];