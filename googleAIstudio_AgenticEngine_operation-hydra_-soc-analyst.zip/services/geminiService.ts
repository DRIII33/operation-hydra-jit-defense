import { GoogleGenAI, Type } from "@google/genai";
import { ComputeAccountLog, AnalysisResult, IntentClassification, EnforcementAction } from "../types";
import { HYDRA_SYSTEM_INSTRUCTION } from "../constants";

export const analyzeComputeLogs = async (logs: ComputeAccountLog[]): Promise<AnalysisResult[]> => {
  if (!process.env.API_KEY) {
    throw new Error("API Key is missing. Please set REACT_APP_GEMINI_API_KEY.");
  }

  const ai = new GoogleGenAI({ apiKey: process.env.API_KEY });

  // JSON Schema for structured output
  const responseSchema = {
    type: Type.ARRAY,
    items: {
      type: Type.OBJECT,
      properties: {
        account_id: { type: Type.STRING },
        intent_classification: { 
          type: Type.STRING, 
          enum: [
            IntentClassification.RESOURCE_HIJACKING, 
            IntentClassification.MODEL_EXTRACTION, 
            IntentClassification.LATERAL_PROPAGATION,
            IntentClassification.BENIGN,
            IntentClassification.UNKNOWN
          ] 
        },
        confidence_score: { type: Type.NUMBER },
        rationale: { type: Type.STRING },
        enforcement_action: { 
          type: Type.STRING,
          enum: [
            EnforcementAction.BLOCK,
            EnforcementAction.THROTTLE,
            EnforcementAction.MONITOR
          ]
        },
      },
      required: ["account_id", "intent_classification", "confidence_score", "rationale", "enforcement_action"],
    },
  };

  try {
    const response = await ai.models.generateContent({
      model: "gemini-3-flash-preview",
      contents: JSON.stringify(logs),
      config: {
        systemInstruction: HYDRA_SYSTEM_INSTRUCTION,
        responseMimeType: "application/json",
        responseSchema: responseSchema,
        temperature: 0.2, // Low temperature for deterministic classification
      },
    });

    const text = response.text;
    if (!text) {
      throw new Error("Empty response from Gemini.");
    }

    const results = JSON.parse(text) as AnalysisResult[];
    return results;

  } catch (error) {
    console.error("Gemini Analysis Failed:", error);
    throw error;
  }
};