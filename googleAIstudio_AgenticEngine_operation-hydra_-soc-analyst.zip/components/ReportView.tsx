import React from 'react';
import { AnalysisResult } from '../types';

interface ReportViewProps {
  results: AnalysisResult[];
  onClose: () => void;
}

const ReportView: React.FC<ReportViewProps> = ({ results, onClose }) => {
  const jsonOutput = JSON.stringify(results, null, 2);
  const timestamp = new Date().toISOString();

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-slate-900/95 backdrop-blur-sm p-4 overflow-y-auto">
      <div className="bg-slate-950 border border-slate-700 w-full max-w-4xl rounded-xl shadow-2xl overflow-hidden flex flex-col max-h-[90vh]">
        {/* Toolbar */}
        <div className="bg-slate-900 p-4 border-b border-slate-800 flex justify-between items-center sticky top-0 z-10">
          <div className="flex items-center gap-2">
            <div className="w-3 h-3 bg-red-500 rounded-full animate-pulse"></div>
            <span className="font-mono text-sm text-slate-400">CONFIDENTIAL // EYES ONLY</span>
          </div>
          <button 
            onClick={onClose}
            className="text-slate-400 hover:text-white transition-colors"
          >
            <svg xmlns="http://www.w3.org/2000/svg" className="h-6 w-6" fill="none" viewBox="0 0 24 24" stroke="currentColor">
              <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M6 18L18 6M6 6l12 12" />
            </svg>
          </button>
        </div>

        {/* Report Content */}
        <div className="p-8 font-mono text-sm overflow-y-auto custom-scrollbar">
          
          {/* Header */}
          <div className="border-b-2 border-slate-700 pb-6 mb-8">
            <h1 className="text-3xl font-display font-bold text-white mb-2">INTELLIGENCE SITREP</h1>
            <div className="grid grid-cols-2 gap-4 text-slate-500 text-xs uppercase tracking-widest">
              <div>REPORT_ID: {Math.random().toString(36).substring(2, 11).toUpperCase()}</div>
              <div>TIMESTAMP: {timestamp}</div>
              <div>ANALYST: AGENT_HYDRA</div>
              <div>CLEARANCE: LEVEL 4</div>
            </div>
          </div>

          {/* Mission & Framework */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-8 mb-8">
            <div>
              <h2 className="text-cyan-400 font-bold mb-3 uppercase tracking-wider border-b border-cyan-900/50 pb-1">1.0 Mission Profile</h2>
              <p className="text-slate-300 leading-relaxed mb-6">
                Analyze aggregated behavioral telemetry from 'v_high_risk_compute' to classify 2026-era JIT malware families (HONESTCUE/PROMPTLOCK) and determine automated mitigation paths.
              </p>
              
              <h3 className="text-slate-400 font-bold mb-2 text-xs uppercase">Intent Categories</h3>
              <ul className="space-y-3 text-xs text-slate-400">
                <li className="flex flex-col gap-1">
                  <span className="text-purple-400 font-bold">RESOURCE_HIJACKING</span>
                  <span className="opacity-80">High CPU + Moderate Pivots. Goal: Unauthorized compute (crypto/botnets).</span>
                </li>
                <li className="flex flex-col gap-1">
                  <span className="text-red-400 font-bold">MODEL_EXTRACTION</span>
                  <span className="opacity-80">Extreme Entropy + Targeted Egress. Goal: Stealing proprietary LLM weights.</span>
                </li>
                <li className="flex flex-col gap-1">
                  <span className="text-orange-400 font-bold">LATERAL_PROPAGATION</span>
                  <span className="opacity-80">High Pivot Count. Goal: Spreading malware across fleet.</span>
                </li>
              </ul>
            </div>

            <div>
              <h2 className="text-cyan-400 font-bold mb-3 uppercase tracking-wider border-b border-cyan-900/50 pb-1">2.0 Detection Heuristics</h2>
              <div className="bg-slate-900/50 p-6 rounded border border-slate-800 space-y-4">
                <div className="flex items-center justify-between p-2 border-b border-slate-800/50">
                    <span className="text-slate-400">Entropy Inspection</span>
                    <div className="text-right">
                        <span className="text-red-400 font-bold block">&gt; 7.2 H</span>
                        <span className="text-[10px] text-slate-600 uppercase">Encrypted Payload</span>
                    </div>
                </div>
                <div className="flex items-center justify-between p-2 border-b border-slate-800/50">
                    <span className="text-slate-400">Compute Profiling</span>
                    <div className="text-right">
                        <span className="text-orange-400 font-bold block">&gt; 90%</span>
                        <span className="text-[10px] text-slate-600 uppercase">JIT Regeneration</span>
                    </div>
                </div>
                <div className="flex items-center justify-between p-2">
                    <span className="text-slate-400">Network Egress</span>
                    <div className="text-right">
                        <span className="text-yellow-400 font-bold block">&gt; 30 Pivots</span>
                        <span className="text-[10px] text-slate-600 uppercase">C2 Activity</span>
                    </div>
                </div>
              </div>
            </div>
          </div>

          {/* JSON Output */}
          <div>
            <h2 className="text-cyan-400 font-bold mb-3 uppercase tracking-wider border-b border-cyan-900/50 pb-1">3.0 Tactical Analysis Output (JSON)</h2>
            <div className="bg-slate-900 p-4 rounded border border-slate-800 relative group">
               <pre className="text-emerald-500 text-xs whitespace-pre-wrap font-mono leading-relaxed">
{jsonOutput}
               </pre>
            </div>
          </div>

        </div>
        
        {/* Footer */}
        <div className="bg-slate-900 p-4 border-t border-slate-800 text-center flex justify-center gap-4">
            <button 
                onClick={() => navigator.clipboard.writeText(jsonOutput)}
                className="px-6 py-2 bg-slate-800 hover:bg-slate-700 text-slate-200 rounded text-xs tracking-widest uppercase transition-colors border border-slate-600 hover:border-cyan-500 flex items-center gap-2"
            >
                <svg xmlns="http://www.w3.org/2000/svg" className="h-4 w-4" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M8 5H6a2 2 0 00-2 2v12a2 2 0 002 2h10a2 2 0 002-2v-1M8 5a2 2 0 002 2h2a2 2 0 002-2M8 5a2 2 0 012-2h2a2 2 0 012 2m0 0h2a2 2 0 012 2v3m2 4H10m0 0l3-3m-3 3l3 3" />
                </svg>
                Copy Payload
            </button>
            <button 
                onClick={onClose}
                className="px-6 py-2 bg-cyan-900/30 hover:bg-cyan-900/50 text-cyan-400 rounded text-xs tracking-widest uppercase transition-colors border border-cyan-800 hover:border-cyan-400"
            >
                Acknowledge & Close
            </button>
        </div>
      </div>
    </div>
  );
};

export default ReportView;