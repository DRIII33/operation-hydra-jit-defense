import React from 'react';
import { ComputeAccountLog } from '../types';

interface TerminalLogProps {
  logs: ComputeAccountLog[];
  setLogs: (logs: ComputeAccountLog[]) => void;
  isLocked: boolean;
}

const TerminalLog: React.FC<TerminalLogProps> = ({ logs, setLogs, isLocked }) => {
  const handleChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    try {
      const parsed = JSON.parse(e.target.value);
      if (Array.isArray(parsed)) {
        setLogs(parsed);
      }
    } catch (err) {
      // Allow user to type, validation happens on submit effectively or visual feedback
      // In a real app we'd track a "text" state separate from "logs" state for better UX
    }
  };

  const formattedLogs = JSON.stringify(logs, null, 2);

  return (
    <div className="glass-panel rounded-lg p-4 font-mono text-sm h-full flex flex-col">
      <div className="flex justify-between items-center mb-2 border-b border-slate-700 pb-2">
        <span className="text-cyan-400 font-bold flex items-center gap-2">
          <span className="w-2 h-2 bg-cyan-400 rounded-full animate-pulse"></span>
          /var/log/compute_stream.json
        </span>
        <span className="text-xs text-slate-500">READ-WRITE ACCESS</span>
      </div>
      <textarea
        className="w-full flex-grow bg-slate-950/50 text-emerald-500 p-2 rounded border border-slate-800 focus:border-cyan-500 focus:ring-1 focus:ring-cyan-500 outline-none resize-none"
        value={formattedLogs}
        onChange={handleChange}
        disabled={isLocked}
        spellCheck={false}
      />
    </div>
  );
};

export default TerminalLog;