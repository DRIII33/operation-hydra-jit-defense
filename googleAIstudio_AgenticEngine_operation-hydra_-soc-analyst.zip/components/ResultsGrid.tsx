import React from 'react';
import { AnalysisResult, EnforcementAction, IntentClassification } from '../types';

interface ResultsGridProps {
  results: AnalysisResult[];
}

const ResultsGrid: React.FC<ResultsGridProps> = ({ results }) => {
  const getActionColor = (action: EnforcementAction) => {
    switch (action) {
      case EnforcementAction.BLOCK: return 'bg-red-500/10 border-red-500 text-red-500 shadow-[0_0_15px_rgba(239,68,68,0.3)]';
      case EnforcementAction.THROTTLE: return 'bg-orange-500/10 border-orange-500 text-orange-400 shadow-[0_0_15px_rgba(249,115,22,0.3)]';
      case EnforcementAction.MONITOR: return 'bg-cyan-500/10 border-cyan-500 text-cyan-400 shadow-[0_0_15px_rgba(6,182,212,0.3)]';
      default: return 'bg-slate-500/10 border-slate-500 text-slate-400';
    }
  };

  const getIntentBadge = (intent: IntentClassification) => {
    switch(intent) {
        case IntentClassification.RESOURCE_HIJACKING: return "bg-purple-900 text-purple-200 border-purple-700";
        case IntentClassification.MODEL_EXTRACTION: return "bg-red-900 text-red-200 border-red-700";
        case IntentClassification.LATERAL_PROPAGATION: return "bg-orange-900 text-orange-200 border-orange-700";
        default: return "bg-slate-800 text-slate-300 border-slate-600";
    }
  };

  return (
    <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4 mt-6">
      {results.map((result) => (
        <div 
          key={result.account_id} 
          className={`border rounded-lg p-5 relative overflow-hidden transition-all duration-300 hover:scale-[1.01] ${getActionColor(result.enforcement_action)}`}
        >
          {/* Header */}
          <div className="flex justify-between items-start mb-4">
            <div>
              <h3 className="text-lg font-display font-bold">{result.account_id}</h3>
              <span className={`text-xs px-2 py-0.5 rounded border mt-1 inline-block ${getIntentBadge(result.intent_classification)}`}>
                {result.intent_classification}
              </span>
            </div>
            <div className="text-right">
              <div className="text-3xl font-bold font-display tracking-tighter">
                {(result.confidence_score * 100).toFixed(0)}%
              </div>
              <div className="text-xs opacity-70">CONFIDENCE</div>
            </div>
          </div>

          {/* Rationale */}
          <p className="text-sm opacity-90 mb-6 font-mono leading-relaxed border-t border-dashed border-current pt-2 mt-2">
            "{result.rationale}"
          </p>

          {/* Footer Action */}
          <div className="absolute bottom-0 left-0 w-full p-2 bg-black/20 backdrop-blur-sm flex justify-between items-center px-5">
            <span className="text-xs uppercase tracking-widest opacity-70">Enforcement</span>
            <span className="font-bold tracking-wider">{result.enforcement_action}</span>
          </div>
          
          {/* Scan Line Animation */}
          <div className="absolute top-0 left-0 w-full h-[2px] bg-white opacity-20 animate-[scan_2s_linear_infinite]" />
        </div>
      ))}
    </div>
  );
};

export default ResultsGrid;