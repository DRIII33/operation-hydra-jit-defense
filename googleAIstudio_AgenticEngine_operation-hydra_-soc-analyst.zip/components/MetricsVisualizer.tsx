import React from 'react';
import { ScatterChart, Scatter, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Cell, ReferenceLine, ZAxis, Legend } from 'recharts';
import { ComputeAccountLog } from '../types';

interface MetricsVisualizerProps {
  data: ComputeAccountLog[];
}

const MetricsVisualizer: React.FC<MetricsVisualizerProps> = ({ data }) => {
  // Determine color based on simple heuristic logic for visual flair before AI analysis
  const getColor = (entry: ComputeAccountLog) => {
    // Extreme Entropy > 7.8 (Model Extraction risk)
    if (entry.avg_entropy > 7.8) return '#ef4444'; // Red-500
    // High CPU > 90% (Resource Hijacking risk)
    if (entry.max_cpu_spike > 90) return '#f97316'; // Orange-500
    return '#22d3ee'; // Cyan-400
  };

  return (
    <div className="h-64 w-full">
      <ResponsiveContainer width="100%" height="100%">
        <ScatterChart
          margin={{
            top: 20,
            right: 20,
            bottom: 20,
            left: 20,
          }}
        >
          <CartesianGrid strokeDasharray="3 3" stroke="#334155" />
          <XAxis 
            type="number" 
            dataKey="avg_entropy" 
            name="Entropy" 
            domain={[0, 10]} 
            stroke="#94a3b8"
            label={{ value: 'Entropy (H)', position: 'insideBottomRight', offset: -10, fill: '#94a3b8' }}
          />
          <YAxis 
            type="number" 
            dataKey="max_cpu_spike" 
            name="CPU Spike" 
            unit="%" 
            stroke="#94a3b8"
            label={{ value: 'CPU Burst %', angle: -90, position: 'insideLeft', fill: '#94a3b8' }}
          />
          <ZAxis type="number" dataKey="max_network_pivots" range={[50, 400]} name="Pivots" />
          
          <Tooltip 
            cursor={{ strokeDasharray: '3 3' }}
            contentStyle={{ backgroundColor: '#1e293b', borderColor: '#475569', color: '#f1f5f9' }}
            itemStyle={{ color: '#f1f5f9' }}
          />
          
          <ReferenceLine x={7.2} stroke="#f87171" strokeDasharray="3 3" label={{ value: "Polymorphic > 7.2", fill: "#f87171", fontSize: 10 }} />
          <ReferenceLine y={90} stroke="#f87171" strokeDasharray="3 3" label={{ value: "JIT Regen > 90%", fill: "#f87171", fontSize: 10 }} />

          <Scatter name="Accounts" data={data} fill="#8884d8">
            {data.map((entry, index) => (
              <Cell key={`cell-${index}`} fill={getColor(entry)} />
            ))}
          </Scatter>
        </ScatterChart>
      </ResponsiveContainer>
    </div>
  );
};

export default MetricsVisualizer;