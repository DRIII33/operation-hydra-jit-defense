import React, { useState } from 'react';
import { ComputeAccountLog, AnalysisResult, EnforcementAction } from './types';
import { DEFAULT_LOGS, MOCK_HISTORY_LOGS } from './constants';
import { analyzeComputeLogs } from './services/geminiService';
import MetricsVisualizer from './components/MetricsVisualizer';
import TerminalLog from './components/TerminalLog';
import ResultsGrid from './components/ResultsGrid';
import ReportView from './components/ReportView';

const App: React.FC = () => {
  const [logs, setLogs] = useState<ComputeAccountLog[]>(DEFAULT_LOGS);
  const [results, setResults] = useState<AnalysisResult[]>([]);
  const [isAnalyzing, setIsAnalyzing] = useState(false);
  const [showReport, setShowReport] = useState(false);
  const [error, setError] = useState<string | null>(null);

  const handleAnalyze = async () => {
    setIsAnalyzing(true);
    setError(null);
    try {
      const data = await analyzeComputeLogs(logs);
      setResults(data);
    } catch (err: any) {
      setError(err.message || "Analysis failed. Verify API Key and Input Format.");
    } finally {
      setIsAnalyzing(false);
    }
  };

  const handleLoadMock = () => {
    setLogs(MOCK_HISTORY_LOGS);
    setResults([]);
  };

  const handleReset = () => {
    setLogs(DEFAULT_LOGS);
    setResults([]);
  };

  const blockCount = results.filter(r => r.enforcement_action === EnforcementAction.BLOCK).length;
  const monitorCount = results.filter(r => r.enforcement_action === EnforcementAction.MONITOR).length;

  return (
    <div className="min-h-screen bg-slate-900 text-slate-100 p-4 md:p-8 relative overflow-hidden">
        {/* Background Grids */}
        <div className="absolute inset-0 bg-[linear-gradient(to_right,#1e293b_1px,transparent_1px),linear-gradient(to_bottom,#1e293b_1px,transparent_1px)] bg-[size:40px_40px] opacity-20 pointer-events-none"></div>

        {/* Header */}
        <header className="flex flex-col md:flex-row justify-between items-center mb-8 border-b border-cyan-900/50 pb-6 relative z-10">
            <div className="flex items-center gap-4">
                <div className="w-12 h-12 bg-cyan-950 border border-cyan-500 rounded flex items-center justify-center relative shadow-[0_0_20px_rgba(6,182,212,0.4)]">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 text-cyan-400" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                        <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12l2 2 4-4m5.618-4.016A11.955 11.955 0 0112 2.944a11.955 11.955 0 01-8.618 3.04A12.02 12.02 0 003 9c0 5.591 3.824 10.29 9 11.622 5.176-1.332 9-6.03 9-11.622 0-1.042-.133-2.052-.382-3.016z" />
                    </svg>
                    <div className="absolute top-0 right-0 w-2 h-2 bg-red-500 rounded-full animate-ping"></div>
                </div>
                <div>
                    <h1 className="text-3xl font-display font-black tracking-wider text-transparent bg-clip-text bg-gradient-to-r from-cyan-400 to-blue-500">
                        OPERATION HYDRA
                    </h1>
                    <p className="text-xs font-mono text-cyan-700 uppercase tracking-[0.2em]">Agentic SOC Analyst // Google Cloud Compute</p>
                </div>
            </div>

            {/* Status Indicators */}
            <div className="flex gap-6 mt-4 md:mt-0 font-mono text-xs">
                <div className="flex flex-col items-end">
                    <span className="text-slate-500">THREAT LEVEL</span>
                    <span className="text-red-500 font-bold animate-pulse">CRITICAL (JIT)</span>
                </div>
                <div className="flex flex-col items-end">
                    <span className="text-slate-500">MODEL</span>
                    <span className="text-cyan-400">GEMINI-3-FLASH</span>
                </div>
                <div className="flex flex-col items-end">
                    <span className="text-slate-500">REGION</span>
                    <span className="text-emerald-400">US-CENTRAL1</span>
                </div>
            </div>
        </header>

        <main className="grid grid-cols-1 lg:grid-cols-12 gap-6 relative z-10">
            
            {/* Left Column: Visuals & Controls */}
            <div className="lg:col-span-7 space-y-6">
                
                {/* Visualizer */}
                <div className="glass-panel p-6 rounded-xl border border-slate-700/50 shadow-2xl">
                    <div className="flex justify-between items-center mb-4">
                        <h2 className="font-display text-lg text-cyan-100 flex items-center gap-2">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-cyan-500" viewBox="0 0 20 20" fill="currentColor">
                                <path d="M2 11a1 1 0 011-1h2a1 1 0 011 1v5a1 1 0 01-1 1H3a1 1 0 01-1-1v-5zM8 7a1 1 0 011-1h2a1 1 0 011 1v9a1 1 0 01-1 1H9a1 1 0 01-1-1V7zM14 4a1 1 0 011-1h2a1 1 0 011 1v12a1 1 0 01-1 1h-2a1 1 0 01-1-1V4z" />
                            </svg>
                            Heuristic Scatter Plot
                        </h2>
                        <div className="flex gap-2">
                             <button onClick={handleLoadMock} className="px-3 py-1 text-xs border border-slate-600 rounded text-slate-400 hover:text-white hover:border-white transition-colors">
                                Load Historical Data
                            </button>
                             <button onClick={handleReset} className="px-3 py-1 text-xs border border-slate-600 rounded text-slate-400 hover:text-white hover:border-white transition-colors">
                                Load Current Batch
                            </button>
                        </div>
                    </div>
                    <MetricsVisualizer data={logs} />
                    <div className="mt-4 flex gap-4 text-xs font-mono text-slate-500 justify-center">
                        <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-red-500"></div>Extreme Entropy</span>
                        <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-orange-500"></div>High Regen</span>
                        <span className="flex items-center gap-1"><div className="w-2 h-2 rounded-full bg-cyan-400"></div>Normal</span>
                    </div>
                </div>

                {/* Dashboard Stats */}
                <div className="grid grid-cols-2 gap-4">
                    <div className="glass-panel p-4 rounded-lg border-l-4 border-red-500">
                        <span className="text-slate-400 text-xs font-mono uppercase">Pending Blocks</span>
                        <div className="text-4xl font-display font-bold text-white mt-1">{blockCount}</div>
                    </div>
                    <div className="glass-panel p-4 rounded-lg border-l-4 border-cyan-500">
                         <span className="text-slate-400 text-xs font-mono uppercase">Monitor Queue</span>
                        <div className="text-4xl font-display font-bold text-white mt-1">{monitorCount}</div>
                    </div>
                </div>

                {/* Action Buttons */}
                <div className="space-y-3">
                    <button 
                        onClick={handleAnalyze} 
                        disabled={isAnalyzing}
                        className={`w-full py-4 rounded-lg font-display font-bold text-xl tracking-widest uppercase transition-all duration-200 
                            ${isAnalyzing 
                                ? 'bg-slate-800 text-slate-500 cursor-not-allowed border border-slate-700' 
                                : 'bg-gradient-to-r from-cyan-600 to-blue-600 hover:from-cyan-500 hover:to-blue-500 text-white shadow-[0_0_20px_rgba(6,182,212,0.5)] hover:shadow-[0_0_30px_rgba(6,182,212,0.7)] border border-cyan-400'
                            }`}
                    >
                        {isAnalyzing ? (
                            <span className="flex items-center justify-center gap-3">
                                <svg className="animate-spin h-5 w-5 text-current" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                    <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                    <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                                </svg>
                                Processing Neural Nets...
                            </span>
                        ) : 'Run Hydra Classification'}
                    </button>

                    {results.length > 0 && (
                        <button 
                            onClick={() => setShowReport(true)}
                            className="w-full py-3 rounded-lg font-display font-bold text-sm tracking-widest uppercase border border-slate-600 hover:border-white text-slate-300 hover:text-white hover:bg-white/5 transition-all duration-200 flex items-center justify-center gap-2"
                        >
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                                <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M9 12h6m-6 4h6m2 5H7a2 2 0 01-2-2V5a2 2 0 012-2h5.586a1 1 0 01.707.293l5.414 5.414a1 1 0 01.293.707V19a2 2 0 01-2 2z" />
                            </svg>
                            Generate Mission Report
                        </button>
                    )}
                </div>

                 {error && (
                    <div className="p-4 bg-red-900/20 border border-red-500/50 rounded text-red-200 font-mono text-sm flex items-start gap-3">
                         <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 text-red-500 flex-shrink-0" viewBox="0 0 20 20" fill="currentColor">
                            <path fillRule="evenodd" d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7 4a1 1 0 11-2 0 1 1 0 012 0zm-1-9a1 1 0 00-1 1v4a1 1 0 102 0V6a1 1 0 00-1-1z" clipRule="evenodd" />
                        </svg>
                        {error}
                    </div>
                )}
            </div>

            {/* Right Column: Terminal Input & Results */}
            <div className="lg:col-span-5 h-[600px] lg:h-auto flex flex-col gap-6">
                 <div className="flex-1 min-h-[300px]">
                    <TerminalLog logs={logs} setLogs={setLogs} isLocked={isAnalyzing} />
                 </div>
            </div>

        </main>

        {/* Results Section - Full Width below */}
        {results.length > 0 && (
             <section className="mt-12 relative z-10 animate-fade-in-up">
                <div className="flex items-center gap-4 mb-6">
                    <h2 className="text-2xl font-display font-bold text-white">Classification Results</h2>
                    <div className="h-px bg-slate-700 flex-grow"></div>
                    <span className="text-cyan-500 font-mono text-sm">BATCH_ID: {Math.random().toString(36).substring(7).toUpperCase()}</span>
                </div>
                <ResultsGrid results={results} />
             </section>
        )}

        {/* Modal Report View */}
        {showReport && (
            <ReportView results={results} onClose={() => setShowReport(false)} />
        )}
    </div>
  );
};

export default App;