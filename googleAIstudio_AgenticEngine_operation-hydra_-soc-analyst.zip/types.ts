export interface ComputeAccountLog {
  account_id: string;
  revenue_tier: 'Enterprise' | 'Free' | 'Standard';
  avg_entropy: number;
  max_cpu_spike: number;
  max_network_pivots: number;
}

export enum IntentClassification {
  RESOURCE_HIJACKING = "RESOURCE_HIJACKING",
  MODEL_EXTRACTION = "MODEL_EXTRACTION",
  LATERAL_PROPAGATION = "LATERAL_PROPAGATION",
  BENIGN = "BENIGN", // Fallback
  UNKNOWN = "UNKNOWN"
}

export enum EnforcementAction {
  BLOCK = "BLOCK",
  THROTTLE = "THROTTLE",
  MONITOR = "MONITOR"
}

export interface AnalysisResult {
  account_id: string;
  intent_classification: IntentClassification;
  confidence_score: number;
  rationale: string;
  enforcement_action: EnforcementAction;
}

export interface HydraState {
  isAnalyzing: boolean;
  logs: ComputeAccountLog[];
  results: AnalysisResult[];
  error: string | null;
}